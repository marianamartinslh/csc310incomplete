<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/x-icon" href="../img/favicon.png" />
    <title>Thank you!</title>
    <style>
   body {
            font-family: Arial, sans-serif;
            color: #ea93a6;
            margin: 0;
            padding: 0;
            background-color: #95E5B0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        header {
            text-align: center;
        }
        h1 {
            color: #EA93A6;
            font-family: Brush Script MT, Brush Script Std, cursive;
            font-size: xx-large;
            margin: 40px; 
        }
        p {
            color: #EA93A6;
            font-family: Arial;
            font-size: x-large;
            margin: 40px;
        }
        .container img {
            display: inline-block;
            width: 200px;
        }
    </style>
</head>
<body>
    <header>
        <!-- confirmation page -->
    <?php
            if(isset($_COOKIE['firstNameCookie'])) {
                echo '<h1>' . $_COOKIE['firstNameCookie'] . ', thank you for reaching out!</h1>';
            } else {
                echo '<h1>Love, thank you for reaching out!</h1>';
            }
        ?>
        <p>We appreciate your interest and will be contacting you soon! </p>
        <div class="container">
        <img src="../img/bye.png" alt="Jo cheering" />
        </div>
    </header>
</body>
</html>