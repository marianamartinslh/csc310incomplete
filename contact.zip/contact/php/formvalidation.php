<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $firstName = $_POST['first-name'];
    $lastName = $_POST['last-name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];
    $stayConnected = $_POST['stay-connected'];
    $country = $_POST['country'];
    $topic = $_POST['topic']; 
    $inquiry = $_POST['inquiry'];
    $contactMethod = $_POST['contact-method'];
    $hearAbout = $_POST['hear-about'];
    
    $emailMessage = "First Name: $firstName\n" .
                    "Last Name: $lastName\n" .
                    "Email: $email\n" .
                    "Phone: $phone\n" .
                    "Message: $message\n" .
                    "Stay connected: $stayConnected\n" .
                    "Country: $country\n" .
                    "Topic: $topic\n" .
                    "Inquiry: $inquiry\n" .
                    "Preferred Contact Method: $contactMethod\n" .
                    "How did you hear about us?: $hearAbout\n";

    // from: https://www.php.net/manual/en/function.mail.php
    $to = 'mmarti16@cord.edu'; // requirement
    $subject = 'Contact Form';
    $headers = 'From: admin@marianamartinslh.com' . "\r\n" .
    'Reply-To: ' . $email . "\r\n";

    if (mail($to, $subject, $emailMessage, $headers)) {
       
        //array with the email to be sent
        $formData = array(
            "firstName" => $firstName,
            "lastName" => $lastName,
            "email" => $email,
            "phone" => $phone,
            "message" => $message,
            "stayConnected" => $stayConnected,
            "country" => $country,
            "topic" => $topic,
            "inquiry" => $inquiry,
            "contactMethod" => $contactMethod,
            "hearAbout" => $hearAbout
        );

        /// COOKIE WITH FIRST NAME
        // from lampl class examples

        $expireTime = time() + 86400 * 30; // 30 days 
        setcookie("firstNameCookie", $firstName, $expireTime, "/");
    
        // sends to confirmation page and gets the name from filled form
        // from: https://www.php.net/manual/en/function.urlencode.php
        header("Location: confirmation.php");
        exit;
    } else {
        header("Location: index.html");
        exit;
    }
}
?>